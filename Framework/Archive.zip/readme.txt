syscalls.c
----------

Implement "_exit()" to do something usefull when assert(...) fails.

project properties
------------------

sprintf() is used in String.h:
	C/C++ Build -> Settings -> MCU Settings -> mark checkbox "Use float with printf from newly-nano …"
 