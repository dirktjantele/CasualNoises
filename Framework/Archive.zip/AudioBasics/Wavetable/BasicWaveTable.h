/*
  ==============================================================================

    BasicWaveTable.h
    Created: 01 aug 2023
    Author:  Dirk Tjantele

  ==============================================================================
*/

#pragma once

#include "CasualNoises.h"

namespace CasualNoises
{

class BasicWaveTable : public WaveTable
{
public:
	BasicWaveTable()
	{

	}

private:

};

} // namespace CasualNoises
